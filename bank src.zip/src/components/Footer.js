import React from 'react';

const Footer = () => {
  return (
    <div className="footer">
       <p>Developed by Sejal Josan &copy; 2024 </p>
    </div>
  );
};

export default Footer;